<?php
require_once dirname(__FILE__).'/config.php';

global $conf;

include $conf->root_path.'/app/kredyt.php';