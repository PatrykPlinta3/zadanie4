<?php

class KredytResult
{
    public $rata;
    public $kwota_kredytu;
}