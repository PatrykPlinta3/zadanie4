<?php

class KredytForm
{
    public $kwota;
    public $lata;
    public $oprocentowanie;
}