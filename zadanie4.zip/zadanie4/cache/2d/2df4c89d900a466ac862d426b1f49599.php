<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* kredyt.html.twig */
class __TwigTemplate_1f106f4ca99d7923ce12a6830dea94f5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("page.html.twig", "kredyt.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Kalkulator kredytowy";
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <form action=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["conf"] ?? null), "app_url", [], "any", false, false, false, 6), "html", null, true);
        echo "/app/kredyt.php\" method=\"post\" class=\"\">
        <label class=\"form-label\" for=\"id_kwota\">Kwota: </label>
        <input class=\"form-control\" id=\"id_kwota\" type=\"number\" step=\"0.01\" name=\"kwota\" value=\"";
        // line 8
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["res"] ?? null), "kwota", [], "any", false, false, false, 8), "html", null, true);
        echo "\"/><br/>

        <label class=\"form-label\" for=\"id_lata\">Ile lat: </label>
        <input class=\"form-control\" id=\"id_lata\" type=\"number\" name=\"lata\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["res"] ?? null), "lata", [], "any", false, false, false, 11), "html", null, true);
        echo "\"/><br/>

        <label class=\"form-label\" for=\"id_oprocentowanie\">Oprocentowanie: </label>
        <input class=\"form-control\" id=\"id_oprocentowanie\" type=\"number\" step=\"0.01\" name=\"oprocentowanie\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["res"] ?? null), "oprocentowanie", [], "any", false, false, false, 14), "html", null, true);
        echo "\"/><br/>

        <div class=\"text-end\">
            <button type=\"submit\" class=\"btn btn-primary\">
                Oblicz
            </button>
        </div>
    </form>

    <br/>

    ";
        // line 25
        if (twig_get_attribute($this->env, $this->source, ($context["msgs"] ?? null), "isErrors", [], "method", false, false, false, 25)) {
            // line 26
            echo "        <div class=\"alert alert-warning\">
            <ol>
                ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["msgs"] ?? null), "getErrors", [], "method", false, false, false, 28));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 29
                echo "                    <li>";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "</li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 31
            echo "            </ol>
        </div>
    ";
        }
        // line 34
        echo "
    ";
        // line 35
        if (twig_get_attribute($this->env, $this->source, ($context["msgs"] ?? null), "isInfos", [], "method", false, false, false, 35)) {
            // line 36
            echo "        <div class=\"alert alert-info\">
            <ol>
                ";
            // line 38
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, ($context["msgs"] ?? null), "getInfos", [], "method", false, false, false, 38));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 39
                echo "                    <li>";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "</li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 41
            echo "            </ol>
        </div>
    ";
        }
        // line 44
        echo "
    ";
        // line 45
        if ( !(null === ($context["res"] ?? null))) {
            // line 46
            echo "        <div class=\"alert alert-success\">
            Wynik: Rata miesięczna wynosi: ";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["res"] ?? null), "rata", [], "any", false, false, false, 47), "html", null, true);
            echo " zł,
            a cała kwota kredytu to: ";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["res"] ?? null), "kwota_kredytu", [], "any", false, false, false, 48), "html", null, true);
            echo " zł.
        </div>
    ";
        }
    }

    public function getTemplateName()
    {
        return "kredyt.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  153 => 48,  149 => 47,  146 => 46,  144 => 45,  141 => 44,  136 => 41,  127 => 39,  123 => 38,  119 => 36,  117 => 35,  114 => 34,  109 => 31,  100 => 29,  96 => 28,  92 => 26,  90 => 25,  76 => 14,  70 => 11,  64 => 8,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "kredyt.html.twig", "C:\\xampp\\htdocs\\zadanie4\\templates\\kredyt.html.twig");
    }
}
