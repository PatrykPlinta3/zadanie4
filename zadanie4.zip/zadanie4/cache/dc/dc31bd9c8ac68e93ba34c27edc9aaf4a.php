<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* calc.html.twig */
class __TwigTemplate_f36d5e5b123e63ff79560bb1392314c1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("page.html.twig", "calc.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Kalkulator";
    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 6
        echo "    <form action=\"";
        echo twig_escape_filter($this->env, ($context["app_url"] ?? null), "html", null, true);
        echo "/app/calc.php\" method=\"post\" class=\"\">
        <label class=\"form-label\" for=\"id_x\">Liczba 1: </label>
        <input class=\"form-control\" id=\"id_x\" type=\"text\" name=\"x\" value=\"";
        // line 8
        echo twig_escape_filter($this->env, ($context["x"] ?? null), "html", null, true);
        echo "\" /><br />

        <label class=\"form-label\" for=\"id_op\">Operacja: </label>
        <select class=\"form-control\" id=\"id_op\" name=\"op\">
            <option value=\"plus\">+</option>
            <option value=\"minus\">-</option>
            <option value=\"times\">*</option>
            <option value=\"div\">/</option>
        </select><br />

        <label class=\"form-label\" for=\"id_y\">Liczba 2: </label>
        <input class=\"form-control\" id=\"id_y\" type=\"text\" name=\"y\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["y"] ?? null), "html", null, true);
        echo "\" /><br />

        <div class=\"text-end\">
            <button type=\"submit\" class=\"btn btn-primary\">
                Oblicz
            </button>
        </div>
    </form>

    <br/>

    ";
        // line 30
        if ( !twig_test_empty(($context["messages"] ?? null))) {
            // line 31
            echo "        <div class=\"alert alert-warning\">
            <ol>
                ";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["messages"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["msg"]) {
                // line 34
                echo "                    <li>";
                echo twig_escape_filter($this->env, $context["msg"], "html", null, true);
                echo "</li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['msg'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 36
            echo "            </ol>
        </div>
    ";
        }
        // line 39
        echo "
    ";
        // line 40
        if ( !(null === ($context["result"] ?? null))) {
            // line 41
            echo "        <div class=\"alert alert-success\">
            Wynik: ";
            // line 42
            echo twig_escape_filter($this->env, ($context["result"] ?? null), "html", null, true);
            echo "
        </div>
    ";
        }
    }

    public function getTemplateName()
    {
        return "calc.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  124 => 42,  121 => 41,  119 => 40,  116 => 39,  111 => 36,  102 => 34,  98 => 33,  94 => 31,  92 => 30,  78 => 19,  64 => 8,  58 => 6,  54 => 5,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "calc.html.twig", "C:\\xampp\\htdocs\\zadanie3\\templates\\calc.html.twig");
    }
}
